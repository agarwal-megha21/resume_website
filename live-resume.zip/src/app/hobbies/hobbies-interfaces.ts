export interface IHobby {
  id: number;
  title: string;
  description: string;
  icon: string;
  backgroundUrl: string;
  color: string;
  position: number;
}
