import { Component, OnInit } from "@angular/core";

@Component({
    selector: "app-page-not-found",
    templateUrl: "./page-not-found.html",
    styleUrls: ["./page-not-found.component.scss", "./page-not-found.component.responsivity.scss", "./page-not-found.keyframes.component.scss"]
})

export class PageNotFoundComponent {

    constructor() {}
}
